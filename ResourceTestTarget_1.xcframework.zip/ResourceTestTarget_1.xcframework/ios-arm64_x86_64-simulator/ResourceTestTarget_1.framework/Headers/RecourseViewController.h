//
//  recourseViewController.h
//  resourceTestTarget_1
//
//  Created by lichenyang on 2023-09-09.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecourseViewController : UIViewController

@end

NS_ASSUME_NONNULL_END

